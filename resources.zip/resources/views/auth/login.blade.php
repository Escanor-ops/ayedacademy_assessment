@extends('includes.master')
@section('title', 'تسجيل الدخول')
@php

    $noAppSection = true;
@endphp
@section('content')
   
    <section class="main registration w-100 d-flex justify-content-center align-items-center">
        <div class="container">
            <form action="" method="POST">
            <form action="{{ route('attempt_login') }}" method="POST">
                @csrf

                <div class="block bg-white mx-auto rounded-5 p-3 position-relative overflow-hidden active" id="first-tab">
                    <div class="first-tab tab w-100 d-flex flex-column p-5 justify-content-between position-relative">
                        <div class="block-header d-flex justify-content-between">
                            <div>
                                <h3 class="fw-bold">تسجيل الدخول</h3>
                                <p class="text-muted fs-18 w-75">أدخل إلى حسابك الشخصي الآن واستمع الى دوراتك المسجلة، وابدأ اختباراتك.</p>
                            </div>
                            <img width="50px" height="50px" src="{{asset('uploads/images/password.svg')}}" alt="password icon">
                        </div>
                        <div class="block-body"> 
                            <div class="row">
                                <div class="col-12">
                                    manager@legend
                                    <br>
                                    employee@legend
                                    <br>
                                    sabry@legend
                                    <br>
                                    <label for="email" class="fw-bold mb-1 fs-14">البريدالإلكتروني</label>
                                    <input type="email" name="email" id="email" class="form-control p-3" placeholder="البريد الإكتروني" value="tox@legend" required>
                                </div>
                                <div class="col-12 mt-2">
                                    <label for="password_confirmation" class="fw-bold mb-1 fs-14">كلمة المرور</label>
                                    <input type="password" name="password" id="password" class="form-control p-3" value="123456" placeholder="كلمة المرور" required>
                                </div>
                            </div>
                        </div>
                        <div class="block-footer mt-3 d-flex justify-content-between">
                            <button type="submit" name="submit" class="btn btn-dark rounded-4 p-3 d-flex gap-3 align-items-center fs-14">دخول <span class="fa fa-arrow-left"></span></button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </section>
    @endsection