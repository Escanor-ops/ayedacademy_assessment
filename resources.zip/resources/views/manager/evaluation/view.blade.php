@extends('includes.master')

@section('title', 'عرض التقييمات')

@section('content')
<section class="main profile">
    <div class="container">
        <div class="row">
            @include('includes.sidebar')
            <div class="col-lg-9 col-md-12">
                <div class="customer-content p-2 mb-5">
                    <div class="d-flex justify-content-between align-items-center">
                        <h3 class="fw-bold">عرض التقييمات - قسم {{ $department->name }}</h3>
                        <a href="{{ route('manager.departments.index', ['month' => $month]) }}" class="btn btn-secondary mt-4">
                            <i class="fa fa-arrow-right"></i> الرجوع
                        </a>
                    </div>

                    <div class="profile-content settings">
                        <div class="alert alert-info my-3">
                            عرض التقييمات الخاصة بشهر: 
                            <strong>{{ \Carbon\Carbon::createFromFormat('Y-m', $month)->translatedFormat('F Y') }}</strong>
                        </div>

                        @if($evaluations->count())
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered text-center align-middle">
                                <thead class="table-dark">
                                    <tr>
                                        <th>اسم الموظف</th>
                                        <th>التقييم العام</th>
                                        <th>حالة التقييم</th>
                                        <th>تفاصيل</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($evaluations as $evaluation)
                                        @php
                                            $employee = $evaluation->employee;
                                            $rating = $evaluation->overall_rating;
                                        @endphp
                                        <tr>
                                            <td>{{ $employee->name }}</td>
                                            <td>
                                                @if ($rating)
                                                    <span class="badge rounded-pill 
                                                        @if($rating >= 85) bg-success
                                                        @elseif($rating >= 70) bg-primary
                                                        @elseif($rating >= 50) bg-warning text-dark
                                                        @else bg-danger
                                                        @endif">
                                                        {{ $rating }} / 100
                                                    </span>
                                                @else
                                                    <span class="text-muted">—</span>
                                                @endif
                                            </td>
                                            <td>
                                                @switch($evaluation->status)
                                                    @case(0)
                                                        <span class="badge bg-warning text-dark">قيد التقييم</span>
                                                        @break
                                                    @case(1)
                                                        <span class="badge bg-info text-dark">تم مراجعة المدير المباشر</span>
                                                        @break
                                                    @case(2)
                                                        <span class="badge bg-success">تم التأكيد</span>
                                                        @break
                                                    @default
                                                        <span class="badge bg-secondary">غير معروف</span>
                                                @endswitch
                                            </td>
                                            <td>
                                                @if($evaluation->status == 1 || $evaluation->status == 2)
                                                    <a href="{{ route('manager.employee.evaluation', [$employee->id, $month]) }}" class="btn btn-sm btn-dark">
                                                        عرض <i class="fa fa-arrow-left"></i>
                                                    </a>
                                                @endif    
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                        @else
                            <div class="alert alert-warning text-center mt-4">
                                ⚠️ لا توجد تقييمات لهذا القسم في هذا الشهر.
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection
