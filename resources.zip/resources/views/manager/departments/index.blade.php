@extends('includes.master')
@section('title', 'الأقسام')

@section('content')

<section class="main profile">
    <div class="container">
        <div class="row">
            @include('includes.sidebar')
            <div class="col-lg-9 col-md-12">
                <div class="customer-content p-2 mb-5">
                    <div class="d-flex justify-content-between align-items-center">
                        <h3 class="fw-bold">تقييمات كل قسم حسب الشهر</h3>
                        <!-- <button class="btn btn-dark rounded" data-bs-toggle="modal" data-bs-target="#addDepartmentModal">
                            <span class="fa fa-plus"></span>
                        </button> -->
                    </div>
                    <div class="profile-content settings">
                    <ul class="nav nav-pills mb-3 px-0 py-3 bg-light">
                        @foreach ($months as $month)
                            <li class="nav-item">
                                <a class="nav-link {{ $month == $selectedMonth ? 'active' : '' }}" 
                                href="{{ route('manager.departments.index', ['month' => $month]) }}">
                                {{ \Carbon\Carbon::createFromFormat('Y-m', $month)->translatedFormat('F Y') }}
                                </a>
                            </li>
                        @endforeach
                    </ul>

                        @if(isset($departments) && $departments->count() > 0)
                        <div class="table-responsive">
                       
                            <table class="table table-striped table-bordered text-center">
                                <thead class="table-dark">
                                    <tr>
                                        <th>#</th>
                                        <th>اسم القسم</th>
                                        <!-- <th>المدير الحالي</th> -->
                                        <th>حالة التقييم</th>
                                        <th>التقييمات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($departments as $index => $department)
                                        <tr>
                                            <td>{{ $index + 1 }}</td>
                                            <td>{{ $department->name }}</td>
                                            <!-- <td>{{ $department->currentManager->name ?? '—' }}</td> -->
                                            <td class="d-flex justify-content-center gap-3">
                                                @if (is_null($department->evaluation_status))
                                                    <span class="badge bg-secondary">Not started</span>
                                                @elseif ($department->evaluation_status === 0)
                                                    <span class="badge bg-warning text-dark">In progress</span>
                                                @elseif ($department->evaluation_status === 1)
                                                    <span class="badge bg-info text-dark">في انتظار تأكيد المدير التنفيذي</span>
                                                    @if (auth()->check() && auth()->user()->status == 1 && $selectedMonth == $currentMonth)
                                                        <form action="{{ route('manager.evaluation.confirm', $department->id) }}" method="POST">
                                                            @csrf
                                                            <input type="hidden" name="month" value="{{ $selectedMonth }}">
                                                            <button type="submit" class="btn btn-sm btn-outline-primary">تأكيد المدير</button>
                                                        </form>
                                                    @endif
                                                @elseif ($department->evaluation_status === 2)
                                                    <span class="badge bg-success">تم التأكيد</span>
                                                @else
                                                        <form action="{{ route('manager.evaluation.confirm', $department->id) }}" method="POST">
                                                            @csrf
                                                            <input type="hidden" name="month" value="{{ $selectedMonth }}">
                                                            <button type="submit" class="btn btn-sm btn-outline-primary">تأكيد المدير</button>
                                                        </form>
                                                @endif
                                            </td>

                                            <td>
                                                @if (auth()->check())
                                                    @if (
                                                        auth()->user()->status == 1 &&
                                                        (
                                                            $department->evaluation_status === 1 ||
                                                            $department->evaluation_status === 2 ||
                                                            $department->evaluation_status === 'Partially reviewed'
                                                        )
                                                    )
                                                        <a href="{{ route('manager.evaluation.view', ['department' => $department->id, 'month' => $selectedMonth]) }}" class="btn btn-sm btn-outline-primary">عرض التقييم</a>
                                                    @elseif (auth()->user()->status == 0 && $department->evaluation_status === 2)
                                                        <a href="{{ route('manager.evaluation.view', ['department' => $department->id, 'month' => $selectedMonth]) }}" class="btn btn-sm btn-outline-primary">عرض التقييم</a>
                                                    @endif
                                                @endif
                                            </td>

                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                        @else
                        <div class="alert alert-warning text-center">⚠️ لا يوجد أقسام حتى الآن.</div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection

@section('js')

@endsection