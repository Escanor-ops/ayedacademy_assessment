<?php $__env->startSection('title', 'عرض التقييمات'); ?>

<?php $__env->startSection('content'); ?>
<section class="main profile">
    <div class="container">
        <div class="row">
            <?php echo $__env->make('includes.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <div class="col-lg-9 col-md-12">
                <div class="customer-content p-2 mb-5">
                    <div class="d-flex justify-content-between align-items-center">
                        <h3 class="fw-bold">عرض التقييمات - قسم <?php echo e($department->name); ?></h3>
                        <a href="<?php echo e(route('manager.departments.index', ['month' => $month])); ?>" class="btn btn-secondary mt-4">
                            <i class="fa fa-arrow-right"></i> الرجوع
                        </a>
                    </div>

                    <div class="profile-content settings">
                        <div class="alert alert-info my-3">
                            عرض التقييمات الخاصة بشهر: 
                            <strong><?php echo e(\Carbon\Carbon::createFromFormat('Y-m', $month)->translatedFormat('F Y')); ?></strong>
                        </div>

                        <?php if($evaluations->count()): ?>
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered text-center align-middle">
                                <thead class="table-dark">
                                    <tr>
                                        <th>اسم الموظف</th>
                                        <th>التقييم العام</th>
                                        <th>حالة التقييم</th>
                                        <th>تفاصيل</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $evaluations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evaluation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $employee = $evaluation->employee;
                                            $rating = $evaluation->overall_rating;
                                        ?>
                                        <tr>
                                            <td><?php echo e($employee->name); ?></td>
                                            <td>
                                                <?php if($rating): ?>
                                                    <span class="badge rounded-pill 
                                                        <?php if($rating >= 85): ?> bg-success
                                                        <?php elseif($rating >= 70): ?> bg-primary
                                                        <?php elseif($rating >= 50): ?> bg-warning text-dark
                                                        <?php else: ?> bg-danger
                                                        <?php endif; ?>">
                                                        <?php echo e($rating); ?> / 100
                                                    </span>
                                                <?php else: ?>
                                                    <span class="text-muted">—</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php switch($evaluation->status):
                                                    case (0): ?>
                                                        <span class="badge bg-warning text-dark">قيد التقييم</span>
                                                        <?php break; ?>
                                                    <?php case (1): ?>
                                                        <span class="badge bg-info text-dark">تم مراجعة المدير المباشر</span>
                                                        <?php break; ?>
                                                    <?php case (2): ?>
                                                        <span class="badge bg-success">تم التأكيد</span>
                                                        <?php break; ?>
                                                    <?php default: ?>
                                                        <span class="badge bg-secondary">غير معروف</span>
                                                <?php endswitch; ?>
                                            </td>
                                            <td>
                                                <?php if($evaluation->status == 1 || $evaluation->status == 2): ?>
                                                    <a href="<?php echo e(route('manager.employee.evaluation', [$employee->id, $month])); ?>" class="btn btn-sm btn-dark">
                                                        عرض <i class="fa fa-arrow-left"></i>
                                                    </a>
                                                <?php endif; ?>    
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <?php else: ?>
                            <div class="alert alert-warning text-center mt-4">
                                ⚠️ لا توجد تقييمات لهذا القسم في هذا الشهر.
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/evaluations/resources/views/manager/evaluation/view.blade.php ENDPATH**/ ?>