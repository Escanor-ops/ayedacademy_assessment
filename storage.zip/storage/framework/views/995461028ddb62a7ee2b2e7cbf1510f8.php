<?php $__env->startSection('title', 'الموظفين'); ?>

<?php $__env->startSection('content'); ?>
<!-- Add Employee Modal -->
<div class="modal fade" id="addEmployeeModal" tabindex="-1" aria-labelledby="addEmployeeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header d-flex justify-content-between">
                <h5 class="modal-title" id="addEmployeeModalLabel">إضافة موظف جديد</h5>
            </div>
            <div class="modal-body">
                <form method="POST" action="<?php echo e(route('admin.employees.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-12 mb-3">
                            <label class="form-label">الاسم</label>
                            <input type="text" name="name" class="form-control" required>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label">البريد الإلكتروني</label>
                            <input type="email" name="email" class="form-control" required>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label">كلمة المرور</label>
                            <input type="password" name="password" class="form-control" required>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label">اسم الوظيفة</label>
                            <input type="text" name="position" class="form-control" required>
                        </div>
                        <div>
                            <label for="department_id">القسم</label>
                            <select class="form-control" name="department_id" id="department_id" required>
                                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($department->id); ?>"><?php echo e($department->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إغلاق</button>
                        <button type="submit" class="btn btn-primary">إضافة الموظف</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Edit Employee Modal -->
<div class="modal fade" id="editEmployeeModal" tabindex="-1" aria-labelledby="editEmployeeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editEmployeeModalLabel">تعديل بيانات الموظف</h5>
            </div>
            <div class="modal-body">
                <form method="POST" id="updateEmployeeForm">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <input type="hidden" id="employee_id" name="employee_id">

                    <div class="row">
                        <div class="col-md-12 mb-3">
                            <label class="form-label">الاسم</label>
                            <input type="text" id="employee_name" name="name" class="form-control" required>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label">البريد الإلكتروني</label>
                            <input type="email" id="employee_email" name="email" class="form-control" required>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label">كلمة المرور</label>
                            <input type="password" name="password" class="form-control" placeholder="كلمة المرور">
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label">اسم الوظيفة</label>
                            <input type="text" id="employee_position" name="position" class="form-control" required>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label">الحالة</label>
                            <select id="employee_status" name="status" class="form-select">
                                <option value="1">نشط</option>
                                <option value="0">غير نشط</option>
                            </select>
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إغلاق</button>
                        <button type="submit" class="btn btn-success">حفظ التعديلات</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<section class="main profile">
    <div class="container">
        <div class="row">
            <?php echo $__env->make('includes.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <div class="col-lg-9 col-md-12">
                <div class="customer-content p-2 mb-5">
                    <div class="d-flex justify-content-between align-items-center">
                        <div class="d-flex align-items-center gap-1">
                            <button id="sidebar-mobile-toggle" class="btn btn-default fs-18 d-none" onclick="_toggle_customer_sidebar()" style="padding:4px 11px;">
                                <span class="fa fa-bars"></span>
                            </button>
                            <h3 class="fw-bold">حسابات الموظفين</h3>
                        </div>
                        <div class="d-flex gap-3">
                            <button class="btn btn-dark rounded" style="padding:4px 10px;" data-bs-toggle="modal" data-bs-target="#addEmployeeModal">
                                <span class="fa fa-plus"></span>
                            </button>
                        </div>
                    </div>
                    <div class="profile-content settings">
                        <div class="tab-content" id="pills-tabContent">
                            <div class="tab-pane fade show active" id="main-info" role="tabpanel">
                                <?php if(isset($employees) && $employees->count() > 0): ?>
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered text-center">
                                            <thead class="table-dark">
                                                <tr>
                                                    <th>#</th>
                                                    <th>الاسم</th>
                                                    <th>البريد الإلكتروني</th>
                                                    <th>الوظيفة</th>
                                                    <th>القسم</th>
                                                    <th>الحالة</th>
                                                    <th>الإجراءات</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($index + 1); ?></td>
                                                        <td><?php echo e($employee->name); ?></td>
                                                        <td><?php echo e($employee->email); ?></td>
                                                        <td><?php echo e($employee->position); ?></td>
                                                        <td><?php echo e($employee->department->name); ?></td>
                                                        
                                                        <td>
                                                            <?php if($employee->status): ?>
                                                                <span class="badge bg-success">نشط</span>
                                                            <?php else: ?>
                                                                <span class="badge bg-danger">غير نشط</span>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td class="d-flex">
                                                            <button class="btn btn-primary btn-sm d-flex align-items-center gap-1 mx-1" onclick="highlightEmployee(this)"
                                                                data-id="<?php echo e($employee->id); ?>"
                                                                data-name="<?php echo e($employee->name); ?>"
                                                                data-email="<?php echo e($employee->email); ?>"
                                                                data-status="<?php echo e($employee->status); ?>"
                                                                data-position="<?php echo e($employee->position); ?>">
                                                                <span class="fa fa-edit"></span> تعديل
                                                            </button>
                                                            <form action="<?php echo e(route('admin.employees.destroy', $employee->id)); ?>" method="POST" class="d-inline">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('DELETE'); ?>
                                                                <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('هل أنت متأكد من حذف هذا الموظف؟')">حذف</button>
                                                            </form>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                        
                                    </div>
                                    <div class="pagination my-4">
                                        <?php echo e($employees->links()); ?>

                                    </div>
                                <?php else: ?>
                                    <div class="alert alert-warning text-center">⚠️ لا يوجد موظفين حتى الآن.</div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>    
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
function highlightEmployee(button) {
    let employeeId = button.getAttribute('data-id');
    let employeeName = button.getAttribute('data-name');
    let employeeEmail = button.getAttribute('data-email');
    let employeeStatus = button.getAttribute('data-status');
    let employeePosition = button.getAttribute('data-position');

    document.getElementById('employee_id').value = employeeId;
    document.getElementById('employee_name').value = employeeName;
    document.getElementById('employee_email').value = employeeEmail;
    document.getElementById('employee_status').value = employeeStatus;
    document.getElementById('employee_position').value = employeePosition;

    document.getElementById('updateEmployeeForm').action = "<?php echo e(url('admin/employees')); ?>/" + employeeId;

    var modal = new bootstrap.Modal(document.getElementById('editEmployeeModal'));
    modal.show();
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/evaluations/resources/views/super/employees/index.blade.php ENDPATH**/ ?>