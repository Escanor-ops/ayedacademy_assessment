<?php $__env->startSection('title', 'المعايير'); ?>

<?php $__env->startSection('content'); ?>
<div class="modal fade" id="addStandardModal" tabindex="-1" aria-labelledby="addStandardModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header d-flex justify-content-between">
                <h5 class="modal-title" id="addStandardModalLabel">إضافة معيار جديد</h5>
            </div>
            <div class="modal-body">
                <form method="POST" action="<?php echo e(route('admin.standards.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label class="form-label">الاسم</label>
                        <input type="text" name="name" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">الوصف</label>
                        <textarea name="description" class="form-control" required></textarea>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إغلاق</button>
                        <button type="submit" class="btn btn-primary">إضافة المعيار</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="editStandardModal" tabindex="-1" aria-labelledby="editStandardModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editStandardModalLabel">تعديل بيانات المعيار</h5>
            </div>
            <div class="modal-body">
                <form method="POST" id="updateStandardForm">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <input type="hidden" id="standard_id" name="standard_id">

                    <div class="row">
                        <div class="col-md-12">
                            <div class="mb-3">
                                <label class="form-label">الاسم</label>
                                <input type="text" id="standard_name" name="name" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="mb-3">
                                <label class="form-label">الوصف</label>
                                <textarea id="standard_description" name="description" class="form-control" required></textarea>
                            </div>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label">الحالة</label>
                            <select id="standard_status" name="status" class="form-select">
                                <option value="1">مفعل</option>
                                <option value="0">غير مفعل</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إغلاق</button>
                        <button type="submit" class="btn btn-success">حفظ التعديلات</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<section class="main profile">
    <div class="container">
        <div class="row">
            <?php echo $__env->make('includes.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <div class="col-lg-9 col-md-12">
                <div class="customer-content p-2 mb-5">
                    <div class="d-flex justify-content-between align-items-center">
                        <h3 class="fw-bold">إدارة المعايير</h3>
                        <button class="btn btn-dark rounded" data-bs-toggle="modal" data-bs-target="#addStandardModal">
                            <span class="fa fa-plus"></span> إضافة معيار جديد
                        </button>
                    </div>
                    <div class="profile-content settings">
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered text-center">
                                <thead class="table-dark">
                                    <tr>
                                        <th>#</th>
                                        <th>الاسم</th>
                                        <th>الوصف</th>
                                        <th>الحالة</th>
                                        <th>الإجراءات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $standards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $standard): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($standard->name); ?></td>
                                            <td><?php echo e($standard->description); ?></td>
                                            <td>
                                                <?php if($standard->status): ?>
                                                    <span class="badge bg-success">مفعل</span>
                                                <?php else: ?>
                                                    <span class="badge bg-danger">غير مفعل</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <button class="btn btn-primary btn-sm" onclick="highlightStandard(this)" 
                                                    data-id="<?php echo e($standard->id); ?>" 
                                                    data-name="<?php echo e($standard->name); ?>" 
                                                    data-status="<?php echo e($standard->status); ?>" 
                                                    data-description="<?php echo e($standard->description); ?>">
                                                    <span class="fa fa-edit"></span> تعديل
                                                </button>
                                                <form action="<?php echo e(route('admin.standards.destroy', $standard->id)); ?>" method="POST" class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('يتم التعطيل اذا كان مرتبط بتقيم سابق والحذف اذا لم يكن!')">تعطيل او حذف</button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <?php if($standards->isEmpty()): ?>
                            <div class="alert alert-warning text-center">⚠️ لا توجد معايير حتى الآن.</div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    function highlightStandard(button) {
        let standardId = button.getAttribute('data-id');
        let standardName = button.getAttribute('data-name');
        let standardDescription = button.getAttribute('data-description');
        let standardStatus = button.getAttribute('data-status');

        // Fill modal inputs
        document.getElementById('standard_id').value = standardId;
        document.getElementById('standard_name').value = standardName;
        document.getElementById('standard_description').value = standardDescription;
        document.getElementById('standard_status').value = standardStatus;


        // Update form action dynamically
        document.getElementById('updateStandardForm').action = "<?php echo e(url('admin/standards')); ?>/" + standardId;

        // Open the modal
        var modal = new bootstrap.Modal(document.getElementById('editStandardModal'));
        modal.show();
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/evaluations/resources/views/super/standards/index.blade.php ENDPATH**/ ?>