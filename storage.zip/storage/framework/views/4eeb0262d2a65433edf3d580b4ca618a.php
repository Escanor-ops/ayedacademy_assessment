<?php $__env->startSection('title', 'الأقسام'); ?>

<?php $__env->startSection('content'); ?>
<div class="modal fade" id="addDepartmentModal" tabindex="-1" aria-labelledby="addDepartmentModalLabel" aria-hidden="true">
    <div class="modal-dialog modal modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header d-flex justify-content-between">
                <h5 class="modal-title" id="addDepartmentModalLabel">إضافة قسم جديد</h5>
            </div>
            <div class="modal-body">
                <form method="POST" action="<?php echo e(route('admin.departments.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label class="form-label">اسم القسم</label>
                        <input type="text" name="name" class="form-control" required>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إغلاق</button>
                        <button type="submit" class="btn btn-primary">إضافة القسم</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="editDepartmentModal" tabindex="-1" aria-labelledby="editDepartmentModalLabel" aria-hidden="true">
    <div class="modal-dialog modal modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editDepartmentModalLabel">تعديل بيانات القسم</h5>
            </div>
            <div class="modal-body">
                <form method="POST" id="updateDepartmentForm">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <input type="hidden" id="department_id" name="department_id">
                    <div class="mb-3">
                        <label class="form-label">اسم القسم</label>
                        <input type="text" id="department_name" name="name" class="form-control" required>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إغلاق</button>
                        <button type="submit" class="btn btn-success">حفظ التعديلات</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<section class="main profile">
    <div class="container">
        <div class="row">
            <?php echo $__env->make('includes.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <div class="col-lg-9 col-md-12">
                <div class="customer-content p-2 mb-5">
                    <div class="d-flex justify-content-between align-items-center">
                        <h3 class="fw-bold">الأقسام</h3>
                        <button class="btn btn-dark rounded" data-bs-toggle="modal" data-bs-target="#addDepartmentModal">
                            <span class="fa fa-plus"></span>
                        </button>
                    </div>
                    <div class="profile-content settings">
                        <?php if(isset($departments) && $departments->count() > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered text-center">
                                <thead class="table-dark">
                                    <tr>
                                        <th>#</th>
                                        <th>اسم القسم</th>
                                        <th>الإجراءات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($index + 1); ?></td>
                                            <td><?php echo e($department->name); ?></td>
                                            <td>
                                                <button class="btn btn-primary btn-sm" onclick="highlightDepartment(this)" 
                                                    data-id="<?php echo e($department->id); ?>" 
                                                    data-name="<?php echo e($department->name); ?>">
                                                    <span class="fa fa-edit"></span> تعديل
                                                </button>
                                                <form action="<?php echo e(route('admin.departments.destroy', $department->id)); ?>" method="POST" class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('هل أنت متأكد من حذف هذا القسم؟')">حذف</button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <?php else: ?>
                        <div class="alert alert-warning text-center">⚠️ لا يوجد أقسام حتى الآن.</div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
function highlightDepartment(button) {
    let departmentId = button.getAttribute('data-id');
    let departmentName = button.getAttribute('data-name');
    
    document.getElementById('department_id').value = departmentId;
    document.getElementById('department_name').value = departmentName;
    document.getElementById('updateDepartmentForm').action = "<?php echo e(url('admin/departments')); ?>/" + departmentId;
    
    var modal = new bootstrap.Modal(document.getElementById('editDepartmentModal'));
    modal.show();
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/evaluations/resources/views/super/departments/index.blade.php ENDPATH**/ ?>