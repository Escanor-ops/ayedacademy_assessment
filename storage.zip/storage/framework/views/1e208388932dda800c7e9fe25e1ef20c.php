<?php $__env->startSection('title', 'تعديل التقييم'); ?>

<?php $__env->startSection('content'); ?>
<section class="main profile">
    <div class="container">
        <div class="row">
            <?php echo $__env->make('includes.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <div class="col-lg-9 col-md-12">
                <div class="customer-content p-4 mb-5">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h3 class="fw-bold">تعديل التقييم - <?php echo e($employee->name); ?></h3>
                        <a href="<?php echo e(route('manager.evaluation.index', ['month' => $month])); ?>" class="btn btn-secondary">
                            <i class="fa fa-arrow-right"></i> العودة
                        </a>
                    </div>

                    <form method="POST" action="<?php echo e(route('manager.evaluation.update', $evaluation->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <input type="hidden" name="employee_id" value="<?php echo e($employee->id); ?>">
                        <input type="hidden" name="month" value="<?php echo e($month); ?>">

                        <!-- Display overall rating -->
                        <div class="mb-4">
                            <h5 class="border-bottom pb-2">التقييم العام: <?php echo e($evaluation->overall_rating); ?></h5>
                        </div>

                        <!-- Global Standards Section -->
                        <div class="mb-4">
                            <h5 class="border-bottom pb-2">المعايير العامة</h5>
                            <?php $__currentLoopData = $globalStandards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $standard): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="mb-3">
                                    <label class="form-label fw-semibold"><?php echo e($standard->name); ?></label>
                                    <input type="number" name="standards[<?php echo e($standard->id); ?>]" class="form-control" 
                                        min="0" max="100" 
                                        value="<?php echo e(old('standards.' . $standard->id, $evaluation->employeeEvaluationDetails->where('standard_id', $standard->id)->first()->score ?? '')); ?>" 
                                        required>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if($globalStandards->isEmpty()): ?>
                                <p class="text-muted">لا توجد معايير عامة.</p>
                            <?php endif; ?>
                        </div>

                        <!-- Employee-Specific Standards Section -->
                        <div class="mb-4">
                            <h5 class="border-bottom pb-2">معايير الموظف</h5>
                            <?php $__currentLoopData = $employeeStandards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $standard): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="mb-3">
                                    <label class="form-label fw-semibold"><?php echo e($standard->name); ?></label>
                                    <input type="number" name="standards[<?php echo e($standard->id); ?>]" class="form-control" 
                                        min="0" max="100" 
                                        value="<?php echo e(old('standards.' . $standard->id, $evaluation->employeeEvaluationDetails->where('standard_id', $standard->id)->first()->score ?? '')); ?>" 
                                        required>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if($employeeStandards->isEmpty()): ?>
                                <p class="text-muted">لا توجد معايير خاصة بهذا الموظف.</p>
                            <?php endif; ?>
                        </div>

                        <div class="text-end">
                            <button type="submit" class="btn btn-success">
                                <i class="fa fa-check"></i> حفظ التقييم
                            </button>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>    
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/evaluations/resources/views/manager/evaluation/edit.blade.php ENDPATH**/ ?>