<?php $__env->startSection('title', 'تفاصيل التقييم'); ?>

<?php $__env->startSection('content'); ?>
<section class="main profile">
    <div class="container">
        <div class="row">
            <?php echo $__env->make('includes.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <div class="col-lg-9 col-md-12">
                <div class="customer-content p-2 mb-5">
                    <div class="d-flex justify-content-between align-items-center">
                        <h3 class="fw-bold">
                            تفاصيل التقييم - <?php echo e($evaluation->employee->name); ?>

                        </h3>

                        <?php if($evaluation->employee->role == 'employee'): ?>
                            <a href="<?php echo e(route('manager.evaluation.view', [$evaluation->department_id ,$evaluation->month])); ?>" class="btn btn-secondary mt-4">
                                <i class="fa fa-arrow-right"></i> الرجوع
                            </a>
                        <?php elseif($evaluation->employee->role == 'department_manager'): ?>
                             <a href="<?php echo e(route('manager.evaluation.index', [$evaluation->month])); ?>" class="btn btn-secondary mt-4">
                                <i class="fa fa-arrow-right"></i> الرجوع
                            </a>
                        <?php endif; ?>
                    </div>

                    <div class="profile-content settings">

                        <div class="alert alert-info my-3">
                            تقييم شهر:
                            <strong><?php echo e(\Carbon\Carbon::createFromFormat('Y-m', $evaluation->month)->translatedFormat('F Y')); ?></strong>
                        </div>
                        <div class="my-4">
                            <strong>التقييم العام:</strong>
                            <span class="badge rounded-pill 
                                <?php if($evaluation->overall_rating >= 85): ?> bg-success
                                <?php elseif($evaluation->overall_rating >= 70): ?> bg-primary
                                <?php elseif($evaluation->overall_rating >= 50): ?> bg-warning text-dark
                                <?php else: ?> bg-danger
                                <?php endif; ?>">
                                <?php echo e($evaluation->overall_rating); ?> / 100
                            </span>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-bordered text-center align-middle">
                                <thead class="table-dark">
                                    <tr>
                                        <th>المعيار</th>
                                        <th>الوصف</th>
                                        <th>الدرجة</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $evaluation->employeeEvaluationDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($detail->standard->name ?? '—'); ?></td>
                                            <td><?php echo e($detail->standard->description ?? '—'); ?></td>
                                            <td>
                                                <?php if($detail->score !== null): ?>
                                                    <span class="badge rounded-pill 
                                                        <?php if($detail->score >= 85): ?> bg-success
                                                        <?php elseif($detail->score >= 70): ?> bg-primary
                                                        <?php elseif($detail->score >= 50): ?> bg-warning text-dark
                                                        <?php else: ?> bg-danger
                                                        <?php endif; ?>">
                                                        <?php echo e($detail->score); ?> / 100
                                                    </span>
                                                <?php else: ?>
                                                    <span class="text-muted">—</span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                        

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/evaluations/resources/views/manager/evaluation/month.blade.php ENDPATH**/ ?>