<?php if($missions->count() > 0): ?>
  <div class="mt-3 d-flex justify-content-end links">
    <?php echo e($missions->links()); ?>

  </div>
  <div class="table-responsive">
    <table class="table table-striped table-bordered text-center">
      <thead class="table-dark">
        <tr>
          <th>#</th>
          <th>عنوان المهمة</th>
          <th>مُعرف المهمة</th>
          <th>صاحب الطلب</th>
          <th>الحالة</th>
          <th>موعد المهمة</th>
          <th>تاريخ الإنشاء</th>
          <th>الإجراء</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $missions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $mission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php
            $missionType = $mission->missionType ?? null;
            $user = $mission->user ?? null;
          ?>
          <tr class="<?php echo e(in_array($mission->id, $newMissions ?? []) ? 'new-mission' : ''); ?>">
            <td><?php echo e($missions->firstItem() + $index); ?></td>
            <td><?php echo e($missionType ? $missionType->name : 'غير متوفر'); ?></td>
            <td><?php echo e($mission->ticket_number); ?></td>
            <td>
              <?php if($user): ?>
                <?php
                  $userRole = $user->role ?? 'unknown';
                  $userDepartmentId = $user->department_id ?? null;
                  $isMyDepartment = $userDepartmentId && $userDepartmentId == auth()->user()->department_id;
                  
                  if ($userRole == 'manager') {
                    $roleClass = 'text-purple fw-bold';
                    $roleText = 'مدير عام';
                  } elseif ($userRole == 'department_manager') {
                    $roleClass = 'text-primary fw-bold';
                    $roleText = 'مدير قسم';
                  } elseif ($isMyDepartment) {
                    $roleClass = 'text-success fw-bold';
                    $roleText = 'زميل';
                  } else {
                    $roleClass = 'text-secondary fw-bold';
                    $roleText = 'موظف';
                  }
                ?>
                <span class="<?php echo e($roleClass); ?>" data-bs-toggle="tooltip" data-bs-placement="top" title="<?php echo e($roleText); ?>">
                  <?php echo e($user->name); ?>

                </span>
              <?php else: ?>
                <span class="text-muted">غير متوفر</span>
              <?php endif; ?>
            </td>
            <td>
              <?php if($mission->status === 0): ?>
                <span class="badge bg-warning text-dark">في الانتظار</span>
              <?php elseif($mission->status === 1): ?>
                <span class="badge bg-primary">تمت الموافقة</span>
              <?php elseif($mission->status === 2): ?>
                <span class="badge bg-danger">مرفوضة</span>
              <?php elseif($mission->status === 3): ?>
                <span class="badge bg-success">مكتملة</span>
              <?php else: ?>
                <span class="badge bg-secondary">غير معروف</span>
              <?php endif; ?>
            </td>
            <td><?php echo e($mission->deadline ?? '-'); ?>  <?php echo e($mission->hour ?? ''); ?></td>
            <td><?php echo e($mission->created_at ? $mission->created_at->format('Y-m-d H:i') : '-'); ?></td>
            <td class="d-flex gap-2 justify-content-center">
              <?php
                $isMyDepartment = auth()->user()->department_id == $department->id;
                $isDepartmentManager = auth()->user()->role == 'department_manager' && 
                                    $user && auth()->user()->department_id == $user->department_id;
                $isManager = auth()->user()->role == 'manager';
                $hasNoDepartment = auth()->user()->department_id === null;
                $isMissionCreator = auth()->user()->id == $mission->user_id;
                
                $canAccessMission = 
                  $isMyDepartment || // Can access if it's my department
                  $isMissionCreator || // Can access if I'm the creator
                  $isDepartmentManager || // Can access if I'm the department manager
                  $isManager || // Can access if I'm a manager
                  $hasNoDepartment; // Can access if I'm super admin/general manager
              ?>
              
              <?php if($canAccessMission): ?>
                <a href="<?php echo e(route('missions.reports', $mission->id)); ?>" class="btn btn-sm btn-primary">تقارير المهمة</a>

                <?php if(auth()->user()->department_id == $department->id && !$isManager): ?>
                  <button class="btn btn-success btn-sm d-flex align-items-center gap-1 mx-1"
                    onclick="highlightMission(this)"
                    data-id="<?php echo e($mission->id); ?>"
                    data-status="<?php echo e($mission->status); ?>"
                    data-name="<?php echo e($missionType ? $missionType->name : 'غير متوفر'); ?>"
                    data-asker="<?php echo e($user ? $user->name : 'غير متوفر'); ?>">
                    <span class="fa fa-edit"></span> تحديث الحالة
                  </button>
                <?php endif; ?>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
<?php else: ?>
  <div class="alert alert-warning text-center">لا توجد مهام تطابق التصفية الحالية.</div>
<?php endif; ?> <?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/evaluations/resources/views/mission/partials/missions-table.blade.php ENDPATH**/ ?>