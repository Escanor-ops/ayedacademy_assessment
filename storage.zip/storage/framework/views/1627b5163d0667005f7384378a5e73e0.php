<?php $__env->startSection('title', 'المهام'); ?>

<?php $__env->startSection('content'); ?>
<section class="main profile">
  <div class="container">
    <div class="row">
      <?php echo $__env->make('includes.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
      <div class="col-lg-9 col-md-12">
        <div class="customer-content p-2 mb-5">
          <div class="d-flex justify-content-between align-items-center">
            <h3 class="fw-bold">المهام حسب الشهر</h3>
            <button class="btn btn-dark rounded" data-bs-toggle="modal" data-bs-target="#addMissionModal">
              <span class="fa fa-plus"></span> طلب مهمة جديدة
            </button>
          </div>
          <div class="profile-content settings">
            <?php if(isset($departments) && $departments->count() > 0): ?>
              <div class="table-responsive">
                <table class="table table-striped table-bordered text-center">
                  <thead class="table-dark">
                    <tr>
                      <th>#</th>
                      <th>اسم القسم</th>
                      <th>حالة المهمة</th>
                      <th>المهام الجارية</th>
                      <th>العمليات</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($department->name); ?></td>
                        <td class="d-flex justify-content-center gap-3">
                          <?php if($department->missions->count() == 0): ?>
                            <span class="badge bg-secondary">لا توجد مهام حالياً</span>
                          <?php elseif($department->missions->where('status', 'pending')->count() > 0): ?>
                            <span class="badge bg-warning text-dark">مهام جارية</span>
                          <?php else: ?>
                            <span class="badge bg-success">كل المهام مكتملة</span>
                          <?php endif; ?>
                        </td>
                        <td>
                          <span class="badge bg-danger">
                            <?php echo e($department->missions->where('status', 'pending')->count()); ?>

                          </span>
                        </td>
                        <td>
                          <a href="<?php echo e(route('department.missions', $department->id)); ?>" class="btn btn-dark btn-sm">
                            <span class="fa fa-pencil-alt"></span> طلب مهمة
                          </a>
                        </td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
            <?php else: ?>
              <div class="alert alert-warning text-center">⚠️ لا يوجد أقسام حتى الآن.</div>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/evaluations/resources/views/Mission/dep.blade.php ENDPATH**/ ?>