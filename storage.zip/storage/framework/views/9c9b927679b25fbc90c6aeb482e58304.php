<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <?php echo $__env->make('includes.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php if (! (isset($noNavbar) && $noNavbar)): ?> 
        <?php echo $__env->make('includes.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>
</head>
<body>
    <?php echo $__env->yieldContent('content'); ?>

    <?php if(isset($loader) && $loader): ?> 
        <?php echo $__env->make('includes.loader', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>
    <?php if (! (isset($noFooter) && $noFooter)): ?> 
        <?php echo $__env->make('includes.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>

    <?php echo $__env->yieldContent('js'); ?>
</body>
</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/evaluations/resources/views/includes/master.blade.php ENDPATH**/ ?>