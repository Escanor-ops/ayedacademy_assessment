<?php $__env->startSection('title', 'الأقسام'); ?>

<?php $__env->startSection('content'); ?>

<section class="main profile">
    <div class="container">
        <div class="row">
            <?php echo $__env->make('includes.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <div class="col-lg-9 col-md-12">
                <div class="customer-content p-2 mb-5">
                    <div class="d-flex justify-content-between align-items-center">
                        <h3 class="fw-bold">تقييمات كل قسم حسب الشهر</h3>
                        <!-- <button class="btn btn-dark rounded" data-bs-toggle="modal" data-bs-target="#addDepartmentModal">
                            <span class="fa fa-plus"></span>
                        </button> -->
                    </div>
                    <div class="profile-content settings">
                    <ul class="nav nav-pills mb-3 px-0 py-3 bg-light">
                        <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="nav-item">
                                <a class="nav-link <?php echo e($month == $selectedMonth ? 'active' : ''); ?>" 
                                href="<?php echo e(route('manager.departments.index', ['month' => $month])); ?>">
                                <?php echo e(\Carbon\Carbon::createFromFormat('Y-m', $month)->translatedFormat('F Y')); ?>

                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>

                        <?php if(isset($departments) && $departments->count() > 0): ?>
                        <div class="table-responsive">
                       
                            <table class="table table-striped table-bordered text-center">
                                <thead class="table-dark">
                                    <tr>
                                        <th>#</th>
                                        <th>اسم القسم</th>
                                        <!-- <th>المدير الحالي</th> -->
                                        <th>حالة التقييم</th>
                                        <th>التقييمات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($index + 1); ?></td>
                                            <td><?php echo e($department->name); ?></td>
                                            <!-- <td><?php echo e($department->currentManager->name ?? '—'); ?></td> -->
                                            <td class="d-flex justify-content-center gap-3">
                                                <?php if(is_null($department->evaluation_status)): ?>
                                                    <span class="badge bg-secondary">Not started</span>
                                                <?php elseif($department->evaluation_status === 0): ?>
                                                    <span class="badge bg-warning text-dark">In progress</span>
                                                <?php elseif($department->evaluation_status === 1): ?>
                                                    <span class="badge bg-info text-dark">في انتظار تأكيد المدير التنفيذي</span>
                                                    <?php if(auth()->check() && auth()->user()->status == 1 && $selectedMonth == $currentMonth): ?>
                                                        <form action="<?php echo e(route('manager.evaluation.confirm', $department->id)); ?>" method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <input type="hidden" name="month" value="<?php echo e($selectedMonth); ?>">
                                                            <button type="submit" class="btn btn-sm btn-outline-primary">تأكيد المدير</button>
                                                        </form>
                                                    <?php endif; ?>
                                                <?php elseif($department->evaluation_status === 2): ?>
                                                    <span class="badge bg-success">تم التأكيد</span>
                                                <?php else: ?>
                                                        <form action="<?php echo e(route('manager.evaluation.confirm', $department->id)); ?>" method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <input type="hidden" name="month" value="<?php echo e($selectedMonth); ?>">
                                                            <button type="submit" class="btn btn-sm btn-outline-primary">تأكيد المدير</button>
                                                        </form>
                                                <?php endif; ?>
                                            </td>

                                            <td>
                                                <?php if(auth()->check()): ?>
                                                    <?php if(
                                                        auth()->user()->status == 1 &&
                                                        (
                                                            $department->evaluation_status === 1 ||
                                                            $department->evaluation_status === 2 ||
                                                            $department->evaluation_status === 'Partially reviewed'
                                                        )
                                                    ): ?>
                                                        <a href="<?php echo e(route('manager.evaluation.view', ['department' => $department->id, 'month' => $selectedMonth])); ?>" class="btn btn-sm btn-outline-primary">عرض التقييم</a>
                                                    <?php elseif(auth()->user()->status == 0 && $department->evaluation_status === 2): ?>
                                                        <a href="<?php echo e(route('manager.evaluation.view', ['department' => $department->id, 'month' => $selectedMonth])); ?>" class="btn btn-sm btn-outline-primary">عرض التقييم</a>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </td>

                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <?php else: ?>
                        <div class="alert alert-warning text-center">⚠️ لا يوجد أقسام حتى الآن.</div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/evaluations/resources/views/manager/departments/index.blade.php ENDPATH**/ ?>