<?php $__currentLoopData = $allMissionTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td class="text-center"><?php echo e($loop->iteration); ?></td>
        <td><?php echo e($type->name); ?></td>
        <td class="text-center">
            <?php if($type->status == 0): ?>
                <span class="badge bg-success">نشط</span>
            <?php else: ?>
                <span class="badge bg-danger">غير نشط</span>
            <?php endif; ?>
        </td>
        <td class="text-center"><?php echo e($type->created_at->format('Y-m-d')); ?></td>
        <?php if(auth()->user()->role == 'department_manager' && auth()->user()->department_id == $type->department_id): ?>
            <td class="text-center">
                <button type="button" 
                        class="btn btn-sm w-75 <?php echo e($type->status == 0 ? 'btn-danger' : 'btn-success'); ?>"
                        onclick="toggleMissionTypeStatus(<?php echo e($type->id); ?>, this)"
                        data-status="<?php echo e($type->status); ?>">
                    <?php echo e($type->status == 0 ? 'تعطيل' : 'تفعيل'); ?>

                </button>
            </td>
        <?php endif; ?>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/evaluations/resources/views/mission/partials/mission-types-table.blade.php ENDPATH**/ ?>