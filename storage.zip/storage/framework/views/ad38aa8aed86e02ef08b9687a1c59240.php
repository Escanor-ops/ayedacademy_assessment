<?php $__env->startSection('title', 'من نحن'); ?>

<?php $__env->startSection('content'); ?>

    <section class="main profile">
        <div class="container">
            <div class="row">
                
                <?php echo $__env->make('includes.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <div class="col-lg-9 col-md-12">
                    <div class="customer-content p-2 mb-5">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="d-flex align-items-center gap-1">
                                <button id="sidebar-mobile-toggle" class="btn btn-default fs-18 d-none" onclick="_toggle_customer_sidebar()" style="padding:4px 11px;"><span class="fa fa-bars"></span></button>
                                <h3 class="fw-bold">ملفي الشخصي</h3>
                            </div>
                            <div class="d-flex gap-3">
                                <a href="#" class="btn btn-dark rounded-circle" style="padding:4px 7px;"><span class="fa fa-graduation-cap"></span></a>
                                <!-- <button class="btn btn-dark rounded-circle fs-14" onclick="_toggle_customer_sidebar()" style="padding:4px 11px;"><span class="fa fa-bars"></span></button> -->
                            </div>
                        </div>
                        <div class="profile-content settings">
                            <ul class="nav nav-pills gap-3 mt-3 p-0 mx-0" id="pills-tab" role="tablist">
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link m-0 rounded-3 active" id="" data-bs-toggle="pill" data-bs-target="#main-info" type="button" role="tab" aria-controls="Update info data" aria-selected="true">البيانات الأساسية</button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link m-0 rounded-3" id="" data-bs-toggle="pill" data-bs-target="#login-info" type="button" role="tab" aria-controls="Update login data" aria-selected="false">بيانات الدخول</button>
                                </li>
                            </ul>

                            <div class="tab-content mt-4" id="pills-tabContent">
                                <div class="tab-pane fade show active" id="main-info" role="tabpanel" aria-labelledby="main info tab">
                                    <div class="card rounded-4 border-0 mb-3">
                                        <div class="card-body p-4">
                                            <form method="POST" action="" class="row">
                                                <?php echo csrf_field(); ?>
                                                <div class="col-md-6">
                                                    <label class="fs-12 fw-bold" for="">الاسم الثلاثي *</label>
                                                    <input type="text" name="name" class="form-control mt-3 rounded-4 bg-ddd" placeholder="الاسم الثلاثي" value="<?php echo e(auth()->user()->name ?? ''); ?>" required>

                                                </div>
                                                <div class="col-md-6 radio-inputs gender-toggle">
                                                    <label class="fs-12 fw-bold d-block mb-3" for="">النوع *</label>
                                                    <div class="row">
                                                        <div class="col-6">
                                                            <label class="w-100">
                                                                <input class="radio-input" type="radio" name="gender" value="male" <?php echo e(auth()->user()->gender == 'male' ? 'checked' : ''); ?>>
                                                                    <span class="radio-tile">
                                                                        <span class="radio-icon">
                                                                            <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 101.47 122.88" style="enable-background:new 0 0 101.47 122.88" xml:space="preserve"><style type="text/css">.st0{fill-rule:evenodd;clip-rule:evenodd;}</style><g><path class="st0" d="M96.4,56.66l0.51,5.66c1.55,0.19,2.69,1.1,3.48,2.51c0.96,1.74,1.24,4.29,0.99,7.08 c-0.24,2.64-0.93,5.54-1.95,8.16c-1.8,4.61-4.67,8.41-8.05,8.88c-0.36,1.16-0.71,2.36-1.05,3.5c-1.73,5.83-3.08,10.4-6.62,14.89 c-3.94,4.99-9.03,8.8-14.42,11.4c-5.92,2.85-12.25,4.25-17.86,4.14c-5.3-0.11-11.33-1.59-17.04-4.36 c-5.2-2.52-10.15-6.1-14.07-10.68c-4.33-5.07-6.13-10.43-8.47-17.4c-0.27-0.81-0.55-1.64-0.81-2.41c-2.97-0.07-5.47-2.59-7.23-6.09 c-1.38-2.72-2.33-6.08-2.68-9.17c-0.37-3.26-0.06-6.32,1.13-8.26c0.83-1.37,2.01-2.23,3.55-2.37l0.5-5.04 c-0.6-3.61-1.29-7.4-1.81-11.02c-0.14-1-0.23-1.97-0.28-2.93C2.07,43.57,0.31,41.56,0,35.92v-9.11 C1.32,15.92,6.39,11.55,14.71,12.8c7.92-8.28,19.1-12.9,34.5-12.78c17.15-0.34,31.77,3.66,42.38,14.53 c5.58,5.56,7.96,14.17,6.52,26.42c0.06,2.32-0.08,4.76-0.45,7.33C97.25,51.08,96.8,53.95,96.4,56.66L96.4,56.66z M36.11,77.78 c0.07,0.26,0.11,0.53,0.11,0.8c0,1.69-1.37,3.07-3.07,3.07c-1.69,0-3.07-1.37-3.07-3.07c0-0.51,0.12-0.99,0.34-1.41 c-1.63,0.11-3.26,0.47-4.9,1.11c-0.7,0.27-1.46-0.15-1.7-0.94c-0.24-0.79,0.13-1.66,0.83-1.93c2.31-0.9,4.63-1.32,6.96-1.3 c2.31,0.02,4.62,0.47,6.92,1.3c0.7,0.25,1.09,1.1,0.87,1.9c-0.22,0.8-0.97,1.24-1.67,0.98C37.2,78.1,36.65,77.93,36.11,77.78 L36.11,77.78z M46.47,89.11c-0.62-0.56-0.66-1.52-0.1-2.14c0.56-0.62,1.52-0.66,2.14-0.1c0.89,0.81,1.73,1.2,2.53,1.19 c0.81-0.01,1.67-0.42,2.58-1.21c0.63-0.55,1.58-0.48,2.13,0.15c0.55,0.63,0.48,1.58-0.15,2.13c-1.46,1.26-2.97,1.93-4.53,1.95 C49.48,91.1,47.95,90.46,46.47,89.11L46.47,89.11z M90.8,74.66c-0.27-0.47-0.11-1.08,0.36-1.35c0.47-0.27,1.08-0.11,1.35,0.36 c1.01,1.76,1.18,3.53-0.04,5.32c-0.31,0.45-0.92,0.57-1.37,0.26c-0.45-0.31-0.57-0.92-0.26-1.37 C91.55,76.84,91.43,75.76,90.8,74.66L90.8,74.66z M9.45,73.68c0.27-0.47,0.88-0.64,1.35-0.36c0.47,0.27,0.64,0.88,0.36,1.35 c-0.63,1.1-0.75,2.18-0.04,3.23c0.31,0.45,0.19,1.07-0.26,1.37C10.41,79.57,9.8,79.45,9.49,79C8.27,77.2,8.44,75.43,9.45,73.68 L9.45,73.68z M80.59,69.21c0.64,0.53,0.74,1.48,0.21,2.12c-0.53,0.64-1.48,0.74-2.12,0.21c-2.39-1.97-7.2-1.1-11.34-0.36 c-2.2,0.4-4.23,0.76-5.85,0.7c-0.83-0.03-1.48-0.73-1.45-1.56c0.03-0.83,0.73-1.48,1.56-1.46c1.31,0.05,3.18-0.29,5.21-0.66 C71.57,67.35,77.13,66.35,80.59,69.21L80.59,69.21z M23.6,71.87c-0.64,0.53-1.59,0.44-2.12-0.21c-0.53-0.64-0.44-1.59,0.21-2.12 c3.46-2.86,9.02-1.86,13.79-1c2.03,0.37,3.91,0.7,5.21,0.66c0.83-0.03,1.53,0.62,1.56,1.46c0.03,0.83-0.62,1.53-1.46,1.56 c-1.62,0.06-3.65-0.31-5.85-0.7C30.81,70.76,25.99,69.9,23.6,71.87L23.6,71.87z M77.72,75.07c0.71,0.23,1.12,1.07,0.92,1.87 c-0.2,0.81-0.94,1.27-1.65,1.04c-1.65-0.54-3.28-0.86-4.89-0.98c0.17,0.38,0.26,0.8,0.26,1.25c0,1.69-1.37,3.07-3.07,3.07 c-1.69,0-3.07-1.37-3.07-3.07c0-0.26,0.03-0.51,0.09-0.75c-0.55,0.13-1.1,0.29-1.64,0.47c-0.71,0.23-1.44-0.23-1.65-1.03 c-0.2-0.8,0.2-1.64,0.91-1.87c2.26-0.75,4.55-1.13,6.85-1.13C73.1,73.94,75.41,74.31,77.72,75.07L77.72,75.07z M8.7,65.21l4.4,2.47 l2.28-13.75c11.18,7.04,23.19,9.79,35.72,9.88c13.09-0.33,25.11-3.26,35.65-9.83l2.09,14.21l4.99-3.12 c0.34,0.56,0.97,0.9,1.66,0.84c0.07-0.01,0.14-0.02,0.21-0.03l0,0c0.8-0.17,1.33,0.1,1.63,0.66c0.6,1.09,0.76,2.93,0.56,5.07 c-0.21,2.29-0.82,4.85-1.73,7.18c-1.51,3.86-3.68,7.02-5.75,6.65c-0.93-0.16-1.82,0.44-2.02,1.35c-0.56,1.76-1,3.23-1.41,4.62 l-9.47,7.78c-2.52,3.11-5.66,3.27-9.36-0.12c-6.72-7.56-27.68-6.06-34.13,0c-2.62,2.78-5.52,3.45-8.93,0.12l-8.81-6.72 c-0.35-1.02-0.7-2.07-1.07-3.16c-0.37-1.11-0.76-2.26-1.28-3.78c-0.3-0.89-1.25-1.37-2.14-1.12l0,0c-1.72,0.49-3.46-1.39-4.81-4.06 C5.76,78,4.94,75.08,4.63,72.38c-0.29-2.54-0.13-4.8,0.63-6.04c0.33-0.55,0.88-0.8,1.7-0.6C7.61,65.9,8.27,65.68,8.7,65.21 L8.7,65.21z M46.12,105.28c-0.87-0.43-1.23-1.48-0.81-2.35c0.43-0.87,1.48-1.23,2.35-0.81c1.47,0.72,2.77,1.06,4.03,1.05 c1.27-0.01,2.57-0.37,4.05-1.07c0.88-0.41,1.93-0.03,2.34,0.85c0.41,0.88,0.03,1.93-0.85,2.34c-1.93,0.91-3.71,1.39-5.52,1.4 C49.89,106.7,48.09,106.24,46.12,105.28L46.12,105.28z"/></g></svg>
                                                                        </span>
                                                                        <span class="radio-label">ذكر</span>
                                                                    </span>
                                                            </label>
                                                        </div>
                                                        <div class="col-6">
                                                            <label class="w-100">
                                                                <input class="radio-input" type="radio" name="gender" value="female" <?php echo e(auth()->user()->gender == 'female' ? 'checked' : ''); ?>>
                                                                <span class="radio-tile">
                                                                    <span class="radio-icon">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 122.54 122.88"><defs><style>.cls-1{fill-rule:evenodd;}</style></defs><title>woman-lady</title><path class="cls-1" d="M10.79,77.86C22,77,26.06,65.35,27.43,53.33c2.1-18.41-.81-42.09,21.35-51C66.37-4.83,89.12,4.75,91.6,30.09c-.1,17.22,4.74,46.52,20.15,47.77-1.14,3.2-6.48,5.58-12.86,6.65,7.5,2,12.87,4.55,16.62,8.69,5.12,5.65,7,14,7,28a1.67,1.67,0,0,1-1.67,1.67H1.67A1.67,1.67,0,0,1,0,121.21c0-13.6,1.81-22,6.64-27.69,3.5-4.13,8.48-6.7,15.41-8.68-5.56-1.25-10.13-3.8-11.26-7Zm45.63-12a1.27,1.27,0,1,1,.86-2.38,11.07,11.07,0,0,0,8-.1,1.27,1.27,0,0,1,1.63.74,1.26,1.26,0,0,1-.73,1.63,13.65,13.65,0,0,1-9.75.11Zm-.6-26.68c1.94.73,2.34,2.35,1.26,3-1.27.72-2.87-.34-4.12-.74-3.24-1-7.09-1.15-9.89.59a15.78,15.78,0,0,0-2.27,1.8A7.8,7.8,0,0,1,42.18,41c2.81-3.54,9.88-3.75,13.64-1.82Zm10.91,0c-1.93.73-2.34,2.35-1.26,3,1.28.72,2.88-.34,4.12-.74,3.24-1,7.09-1.15,9.89.59a15.83,15.83,0,0,1,2.28,1.8A8,8,0,0,0,80.37,41c-2.81-3.54-9.88-3.75-13.64-1.82Zm-21.47,7a.86.86,0,0,1-.55-.59.94.94,0,0,1,.5-1.15,13.36,13.36,0,0,1,9.66,0,.93.93,0,0,1,.52,1.13.77.77,0,0,1-1,.59c-.53-.19-1.07-.35-1.59-.48a3,3,0,0,1,.07.6,2.24,2.24,0,1,1-4.47,0,2.2,2.2,0,0,1,.17-.86,12.22,12.22,0,0,0-2.41.57,1.4,1.4,0,0,1-.91.19Zm25.06-.56a2.4,2.4,0,0,0-.11.66,2.24,2.24,0,1,0,4.48,0,2.19,2.19,0,0,0-.23-1,14.48,14.48,0,0,1,3,.65.79.79,0,0,0,1-.63.94.94,0,0,0-.55-1.12A15.39,15.39,0,0,0,73,43.35a14.86,14.86,0,0,0-4.77.79.94.94,0,0,0-.55,1.12.79.79,0,0,0,1,.62,13.78,13.78,0,0,1,1.58-.43c.15,0,.11-.07.06.11ZM82.7,84.21a21.78,21.78,0,0,1-3.45-1.12,20.69,20.69,0,0,1-3.41-1.62,4.42,4.42,0,0,1-1.38-1.81,7.29,7.29,0,0,1-1.54-4.23c-.32-1.12-.43-1.61-.58-2.12-7,4.59-15.69,5.47-22.76.47-.09,2.19-1.31,7.2-3.28,8.4C43,84.16,37.8,85,34,85.64c-.91.15-1.75.29-2.49.43-1.22.24-2.39.48-3.52.73,10.87,10.56,21.8,16.46,32.81,16.79s22.31-4.94,33.86-16.72c-1.68-.4-3.46-.78-5.35-1.16l-.27,0c-1.63-.33-3.93-.79-6.3-1.45ZM76,68.06c9.84-10.89,11.55-19.67,8.64-34.18C77.8,30.71,73.32,23.72,71,13.23,68.28,33.21,43.75,32.35,37.58,36c0,9.08-1.19,15.43,2.81,23.71h0a49.78,49.78,0,0,0,2.78,5,25,25,0,0,0,2.73,3.81c8.24,8.88,22.33,7.77,30.12-.48Z"/></svg>
                                                                    </span>
                                                                    <span class="radio-label">أنثى</span>
                                                                </span>
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-12 mt-3 text-start">
                                                    <button type="submit" name="" class="btn btn-primary rounded-4 w-100 p-3 fs-12 fw-bold shadow-sm">حفظ البيانات</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane" id="login-info" role="tabpanel" aria-labelledby="main info tab">
                                    <div class="card rounded-4 border-0 mb-3">
                                        <div class="card-body p-4">
                                            <form method="POST" action="" class="row">
                                                <?php echo csrf_field(); ?>
                                                <div class="col-md-6">
                                                    <label class="fs-12 fw-bold" for="">كلمة المرور الجديدة *</label>
                                                    <input type="password" name="password" class="form-control mt-3 rounded-4 bg-ddd" placeholder="كلمة المرور الجديدة" required autocomplete>
                                                </div>
                                                <div class="col-md-6">
                                                    <label class="fs-12 fw-bold" for="">تأكيد كلمة المرور الجديدة *</label>
                                                    <input type="password" name="password_confirmation" class="form-control mt-3 rounded-4 bg-ddd" placeholder="تأكيد كلمة المرور الجديدة" required autocomplete>
                                                </div>
                                                <div class="col-12 mt-1">
                                                    <div class="alert alert-warning rounded-3 p-3 fs-14">يجب أن يتجاوز عدد أحرف كلمة المرور ٧ أحرف</div>
                                                </div>
                                                <div class="col-md-12 mt-2 text-start">
                                                    <button type="submit" name="" class="btn btn-primary rounded-4 w-100 p-3 fs-12 fw-bold shadow-sm">حفظ البيانات</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
    
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>    
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/evaluations/resources/views/super/home/index.blade.php ENDPATH**/ ?>