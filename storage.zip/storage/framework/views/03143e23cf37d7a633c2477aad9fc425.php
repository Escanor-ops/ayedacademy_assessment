<?php $__env->startSection('title', 'مهام القسم'); ?>

<?php $__env->startSection('content'); ?>
<style>
  .btn.active{
    background:#198754 !important;
    border-color:none !important !important;
  }
  .pagination{
    align-self:flex-end;
  }
</style>

<!-- Modal -->
<div class="modal fade" id="missionModal" tabindex="-1" aria-labelledby="missionModal" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header d-flex justify-content-between">
        <h5 class="modal-title" id="addStandardModalLabel">إضافة مهمة جديدة</h5>
      </div>
      <div class="modal-body">
        <form action="<?php echo e(route('mission.add')); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="department_id" value="<?php echo e($department->id); ?>">

          <div class="mb-3">
          <label for="mission_type" class="form-label">
            نوع المهمة 
        </label>

            <select id="mission_type" name="mission_type_id" class="form-select">
              <?php $__currentLoopData = $missionTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>

          <div class="mb-3">
            <label for="description" class="form-label">وصف المهمة<span style="color: red">*</span></label>
            <textarea id="description" name="description" class="form-control" rows="3" placeholder="من فضلك اجعل وصفك للطلب واضحا" required></textarea>
          </div>
          <div class="mb-3">
            <label for="mission_link">لينك المهمة</label>
            <input type="text" class="form-control" name="link" placeholder="يمكنك أرفاق لينك هنا أذا توفر">
          </div>
          <div class="mb-3">
            <label for="mission_link">تحديد موعد</label>
            <div class="d-flex gap-2">
              <input type="date" name="date" class="form-control">
              <input type="time" name="hour" class="form-control" >
            </div>
          </div>

          <div class="mb-3 text-end">
            <button type="submit" class="btn btn-success">ارسال المهمة</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<!-- Update Mission Status Modal -->
<div class="modal fade" id="updateMissionStatusModal" tabindex="-1" aria-labelledby="updateMissionStatusModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content bg-dark">
            <div class="modal-header">
                <h5 class="modal-title text-light">تحديث حالة المهمة</h5>
              
            </div>
            <div class="modal-body">
                 <div class="my-2 p-2 text-light bg-danger">
                  <span id="mission_asker"></span>
                  <br>
                  <span  id="mission_typeName"></span>
                </div>
                <form method="POST" id="updateMissionStatusForm" action="<?php echo e(route('mission.updateStatus')); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" id="mission_id" name="mission_id">
                    <input type="hidden" id="mission_status" name="status">

                    <div class="mb-3 py-2">
                        <div class="btn-group w-100 text-white" role="group">
                            <button type="button" class="btn rounded-0 border-0 status-tab text-light" data-status="0">في الانتظار</button>
                            <button type="button" class="btn rounded-0 border-0 status-tab text-light" data-status="1">تمت الموافقة</button>
                            <button type="button" class="btn rounded-0 border-0  status-tab text-light " data-status="3">مكتملة</button>
                            <button type="button" class="btn rounded-0 border-0 status-tab text-light" data-status="2">مرفوضة</button>

                        </div>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إغلاق</button>
                        <button type="submit" class="btn btn-success">تحديث الحالة</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>



<section class="main profile">
  <div class="container-xl">
    <div class="row">
      <?php echo $__env->make('includes.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

      <div class="col-lg-9 col-md-12">
        <div class="customer-content p-2 mb-5">
          <div class="d-flex justify-content-between align-items-center mb-3">
            <h3 class="fw-bold mb-0">مهام قسم: <?php echo e($department->name); ?></h3>
            <button type="button" class="btn btn-dark" data-bs-toggle="modal" data-bs-target="#missionModal">
              إضافة مهمة جديدة
            </button>
          </div>

          <!-- FILTERS WITH TABS START -->
          <form method="GET" class="mb-4">

                <!-- Status Tabs -->
                <label class="form-label fw-bold d-block mb-1">تصفية حسب الحالة:</label>
                <ul class="nav nav-pills mb-3">
                  <?php
                    $statusFilter = request('status');
                  ?>
                  <li class="nav-item">
                    <a class="nav-link m-0 <?php echo e(is_null($statusFilter) || $statusFilter === '' ? 'active' : ''); ?>" href="?<?php echo e(http_build_query(array_merge(request()->except(['status', 'page'])))); ?>">جميع المهام</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link m-0 <?php echo e($statusFilter === '0' ? 'active' : ''); ?>" href="?<?php echo e(http_build_query(array_merge(request()->except(['status', 'page']), ['status' => '0']))); ?>">في الانتظار</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link m-0 <?php echo e($statusFilter === '1' ? 'active' : ''); ?>" href="?<?php echo e(http_build_query(array_merge(request()->except(['status', 'page']), ['status' => '1']))); ?>">تمت الموافقة</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link m-0 <?php echo e($statusFilter === '2' ? 'active' : ''); ?>" href="?<?php echo e(http_build_query(array_merge(request()->except(['status', 'page']), ['status' => '2']))); ?>">مرفوضة</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link m-0 <?php echo e($statusFilter === '3' ? 'active' : ''); ?>" href="?<?php echo e(http_build_query(array_merge(request()->except(['status', 'page']), ['status' => '3']))); ?>">مكتملة</a>
                  </li>
                </ul>

                <!-- Asker Tabs -->
                <label class="form-label fw-bold d-block mb-1">تصفية حسب الطالب:</label>
                <ul class="nav nav-pills mb-3">
                  <?php
                    $askerFilter = request('asker');
                  ?>
                  <li class="nav-item">
                    <a class="nav-link m-0 <?php echo e(is_null($askerFilter) || $askerFilter === '' ? 'active' : ''); ?>" href="?<?php echo e(http_build_query(array_merge(request()->except(['asker', 'page'])))); ?>">كل المستخدمين</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link m-0 <?php echo e($askerFilter === 'me' ? 'active' : ''); ?>" href="?<?php echo e(http_build_query(array_merge(request()->except(['asker', 'page']), ['asker' => 'me']))); ?>">أنا</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link m-0 <?php echo e($askerFilter === 'my_department' ? 'active' : ''); ?>" href="?<?php echo e(http_build_query(array_merge(request()->except(['asker', 'page']), ['asker' => 'my_department']))); ?>">قسمي</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link m-0 <?php echo e($askerFilter === 'others' ? 'active' : ''); ?>" href="?<?php echo e(http_build_query(array_merge(request()->except(['asker', 'page']), ['asker' => 'others']))); ?>">أقسام أخرى</a>
                  </li>
                </ul>

                </form>

          <!-- FILTERS WITH TABS END -->

          <div class="profile-content settings">
            <?php if($missions->count() > 0): ?>
              <div class="mt-3 d-flex justify-content-end links">
                <?php echo e($missions->links()); ?>

              </div>
              <div class="table-responsive">
                <table class="table table-striped table-bordered text-center">
                  <thead class="table-dark">
                    <tr>
                      <th>#</th>
                      <th>عنوان المهمة</th>
                      <th>مُعرف المهمة</th>
                      <!-- <th>الوصف</th> -->
                      <th>صاحب الطلب</th>
                      
                      <th>الحالة</th>
                      <th>موعد المهمة</th>
                      <th>تاريخ الإنشاء</th>
                      <?php if(auth()->user()->department_id == $department->id): ?>
                        <th>الإجراء</th>
                      <?php endif; ?>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $missions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $mission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><?php echo e($missions->firstItem() + $index); ?></td>
                        <td><?php echo e($mission->missionType->name); ?></td>
                        <td><?php echo e($mission->ticket_number); ?></td>
                        <!-- <td><?php echo e($mission->description); ?></td> -->
                        
                        <td><?php echo e($mission->user->name); ?></td>
                        <td>
                          <?php if($mission->status === 0): ?>
                            <span class="badge bg-warning text-dark">في الانتظار</span>
                          <?php elseif($mission->status === 1): ?>
                            <span class="badge bg-primary">تمت الموافقة</span>
                          <?php elseif($mission->status === 2): ?>
                            <span class="badge bg-danger">مرفوضة</span>
                          <?php elseif($mission->status === 3): ?>
                            <span class="badge bg-success">مكتملة</span>
                          <?php else: ?>
                            <span class="badge bg-secondary">غير معروف</span>
                          <?php endif; ?>
                        </td>
                        <td><?php echo e($mission->deadline); ?>  <?php echo e($mission->time); ?></td>
                        <td><?php echo e($mission->created_at->format('Y-m-d H:i')); ?></td>
                        <?php if(auth()->user()->department_id == $department->id): ?>
                          <td class="d-flex gap-2 justify-content-center">
                            <a href="<?php echo e(route('missions.reports', $mission->id)); ?>" class="btn btn-sm btn-primary">تقارير المهمة</a>

                            <button class="btn btn-success btn-sm d-flex align-items-center gap-1 mx-1"
                              onclick="highlightMission(this)"
                              data-id="<?php echo e($mission->id); ?>"
                              data-status="<?php echo e($mission->status); ?>"
                              data-name="<?php echo e($mission->missionType->name); ?>"
                              data-asker="<?php echo e($mission->user->name); ?>">
                              <span class="fa fa-edit"></span> تحديث الحالة
                          </button>
                          </td>
                        <?php endif; ?>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>

              

            <?php else: ?>
              <div class="alert alert-info text-center">لا توجد مهام تطابق التصفية الحالية.</div>
            <?php endif; ?>
          </div> <!-- profile-content settings -->
        </div> <!-- customer-content -->
      </div> <!-- col-lg-9 -->
    </div> <!-- row -->
  </div> <!-- container -->
</section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
function highlightMission(button) {
    let missionId = button.getAttribute('data-id');
    let missionStatus = button.getAttribute('data-status');
    let missionType = button.getAttribute('data-name');
    let missionAsker = button.getAttribute('data-asker');
    // Set mission id
    document.getElementById('mission_id').value = missionId;

    // Preselect status tab
    let tabs = document.querySelectorAll('.status-tab');
    tabs.forEach(function(tab) {
        tab.classList.remove('active');
        if (tab.getAttribute('data-status') === missionStatus) {
            tab.classList.add('active');
        }
    });

    // Set hidden input value
    document.getElementById('mission_status').value = missionStatus;
    document.getElementById('mission_typeName').innerHTML = missionType;
    document.getElementById('mission_asker').innerHTML = missionAsker;

    // Make tabs clickable & update hidden input + active class
    tabs.forEach(function(tab) {
        tab.onclick = function() {
            tabs.forEach(t => t.classList.remove('active'));
            this.classList.add('active');
            document.getElementById('mission_status').value = this.getAttribute('data-status');
        };
    });

    // Open modal
    var modal = new bootstrap.Modal(document.getElementById('updateMissionStatusModal'));
    modal.show();
}
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/evaluations/resources/views/Mission/dept.blade.php ENDPATH**/ ?>