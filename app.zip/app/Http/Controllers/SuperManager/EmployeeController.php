<?php

namespace App\Http\Controllers\SuperManager;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Department; // Make sure to import the Department model
use Illuminate\Http\Request;

class EmployeeController extends Controller
{
    public function index()
    {
        // Get all employees with 'role' as 'employee' and get departments
        $employees = User::where('role', 'employee')->paginate(20);
        $departments = Department::all(); 

        return view('super.employees.index', compact('employees', 'departments'));
    }

    public function create()
    {
        $departments = Department::all(); // Get all departments for the 'create' view
        return view('super.employees.create', compact('departments'));
    }

    public function store(Request $request)
    {
        
        $request->validate([
            'name'     => 'required|string|max:255',
            'position'     => 'required|string|max:255',
            'email'    => 'required|email|unique:users,email',
            'password' => 'required|min:6',
            'department_id' => 'required|exists:departments,id', 
        ]);

        // Create new employee
        User::create([
            'name'          => $request->name,
            'email'         => $request->email,
            'password'      => bcrypt($request->password),
            'role'          => 'employee',
            'position'          => $request->position,
            'status'        =>  1,
            'department_id' => $request->department_id, // Save the department_id
        ]);

        return redirect()->route('admin.employees.index')->with('success', 'تم إضافة الموظف بنجاح');
    }

    public function edit($id)
    {
        $employee = User::findOrFail($id);
        $departments = Department::all(); // Get all departments for editing
        return view('super.employees.edit', compact('employee', 'departments'));
    }

    public function update(Request $request, $id)
    {
        $employee = User::findOrFail($id);


        $request->validate([
            'name'     => 'required|string|max:255',
            'position'     => 'required|string|max:255',
            'email'    => 'required|email|unique:users,email,' . $id,
            'password' => 'nullable|min:6',
            'department_id' => 'nullable|exists:departments,id', 
        ]);

        $data = [
            'name'          => $request->name,
            'position'      => $request->position,
            'email'         => $request->email,
            'status'        => $request->status ?? 0,
            'department_id' => $request->department_id ??  $employee->department_id// Update department_id
        ];

        if ($request->filled('password')) {
            $data['password'] = bcrypt($request->password);
        }

        $employee->update($data);

        return redirect()->route('admin.employees.index')->with('success', 'تم تعديل بيانات الموظف بنجاح');
    }

    public function destroy($id)
    {
        $employee = User::findOrFail($id);
        $employee->delete();

        return redirect()->route('admin.employees.index')->with('success', 'تم حذف الموظف بنجاح');
    }
}
