<?php

namespace App\Http\Controllers\SuperManager;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Department;
use Illuminate\Support\Facades\Hash;

class DepartmentManagerController extends Controller
{
    /**
     * Display a listing of department managers.
     */
    public function index()
    {
        $departmentManagers = User::with('department')->where('role', 'department_manager')->get();
        $departments = Department::select('id', 'name')->get();
        return view('super.departments.managers', compact('departmentManagers','departments'));
    }

    /**
     * Show the form for creating a new department manager.
     */
    public function create()
    {
        return view('super.department_managers.create');
    }

    /**
     * Store a newly created department manager in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'name'         => 'required|string|max:255',
            'email'        => 'required|email|unique:users,email',
            'password'     => 'required|min:6',
            'manager_id'   => 'nullable|exists:users,id',
            'department_id'=> 'nullable|exists:departments,id'
        ]);

        User::create([
            'name'          => $request->name,
            'email'         => $request->email,
            'password'      => Hash::make($request->password),
            'role'          => 'department_manager',
            'position'      => 'department manager',
            'manager_id'    => $request->manager_id,
            'department_id' => $request->department_id,
            'status'        => 0
        ]);

        return redirect()->route('admin.departments-managers.index')->with('success', 'تم إضافة مدير القسم بنجاح');
    }

    /**
     * Show the form for editing a department manager.
     */
    public function edit($id)
    {
        $departmentManager = User::findOrFail($id);
        return view('super.department_managers.edit', compact('departmentManager'));
    }

    /**
     * Update the specified department manager in storage.
     */
    public function update(Request $request, $id)
    {
        $departmentManager = User::findOrFail($id);
        
        $request->validate([
            'name'         => 'required|string|max:255',
            'email'        => 'required|email|unique:users,email,' . $id,
            'password'     => 'nullable|min:6',
            'manager_id'   => 'nullable|exists:users,id',

        ]);
        if ($request->status == 1) {
            $duplicateActive = User::where('id', '!=', $id)
                ->where('role', $departmentManager->role)
                ->where('department_id', $departmentManager->department_id)
                ->where('status', 1)
                ->first();
    
            if ($duplicateActive) {
                return redirect()->route('admin.departments-managers.index')->with('failed', 'يوجد مدير نشط لهذا القسم بالفعل');
            }
        }

        $data = [
            'name'          => $request->name,
            'email'         => $request->email,
            'manager_id'    => $request->manager_id,
            'status'     => $request->status,

        ];

        if ($request->filled('password')) {
            $data['password'] = Hash::make($request->password);
        }

        $departmentManager->update($data);


        return redirect()->route('admin.departments-managers.index')->with('success', 'تم تعديل بيانات مدير القسم بنجاح');
    }

    /**
     * Remove the specified department manager from storage.
     */
    public function destroy($id)
    {
        $departmentManager = User::findOrFail($id);
        $departmentManager->delete();

        return redirect()->route('admin.departments-managers.index')->with('success', 'تم حذف مدير القسم بنجاح');
    }
}
