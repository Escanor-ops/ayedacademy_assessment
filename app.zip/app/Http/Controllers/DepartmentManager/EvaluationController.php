<?php

namespace App\Http\Controllers\DepartmentManager;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Standard;
use App\Models\EmployeeEvaluation;
use App\Models\EmployeeEvaluationDetail;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;

class EvaluationController extends Controller
{
    public function index(Request $request)
{

    $manager = auth()->user();

    // Get the current month
    $currentMonth = Carbon::now()->format('Y-m');

    // Get selected month from query (default to current)
    $selectedMonth = $request->get('month', $currentMonth);

    // Get last 5 months that have evaluations for employees in the same department
    $months = EmployeeEvaluation::whereHas('employee', function ($query) use ($manager) {
        $query->where('department_id', $manager->department_id)
            ->where('role', 'employee');
    })
    ->select('month')
    ->distinct()
    ->orderByDesc('month')
    ->limit(12)
    ->pluck('month');

    // Ensure current month is always in the list
    if (!$months->contains($currentMonth)) {
        $months->prepend($currentMonth);
    }

    // If selected month is not available, fallback to the latest available
    if (!$months->contains($selectedMonth)) {
        $selectedMonth = $months->first();
    }

    // Check if there is any evaluation with status 0 for the selected month in the current department
    $evaluationInProgress = EmployeeEvaluation::where('month', $selectedMonth)
        ->where('status', 0)
        ->whereHas('employee', function ($query) use ($manager) {
            $query->where('department_id', $manager->department_id);
        })
        ->exists(); // True if any evaluation with status 0 exists in the department for the selected month

    // Main logic: show employees based on selected month
    if ($selectedMonth === $currentMonth) {
        // Show ALL current employees in the department
        $employees = User::where('role', 'employee')
            ->where('department_id', $manager->department_id)
            ->where('status', 1)
            ->with(['employeeEvaluations' => function ($query) use ($selectedMonth) {
                $query->where('month', $selectedMonth);
            }])
            ->paginate(10)
            ->appends(['month' => $selectedMonth]);
    } else {
        // Show only employees who had evaluations in that past month
        $employees = User::where([
                ['role', '=', 'employee'],
                ['department_id', '=', $manager->department_id],
                ['status', '=', 1]
            ])
            ->whereHas('employeeEvaluations', function ($query) use ($selectedMonth) {
                $query->where('month', $selectedMonth);
            })
            ->with(['employeeEvaluations' => function ($query) use ($selectedMonth) {
                $query->where('month', $selectedMonth);
            }])
            ->paginate(10)
            ->appends(['month' => $selectedMonth]);
    }

    // Attach evaluation to each employee
    foreach ($employees as $employee) {
        $employee->evaluation = $employee->employeeEvaluations->first();
    }

    // Pass the evaluationInProgress flag to the view
    return view('department.evaluation.index', compact('employees', 'months', 'selectedMonth', 'evaluationInProgress'));
}

public function create(Request $request)
    {
        $employee = User::findOrFail($request->employee);
        $month = $request->month;
    
        // Global standards (for all employees)
        $globalStandards = Standard::where('type', 'global')->get();
    
        // Employee-specific standards
        $employeeStandards = Standard::where('type', 'employee')
            ->where('employee_id', $employee->id)
            ->get();
    
        return view('department.evaluation.create', compact(
            'employee', 'month', 'globalStandards', 'employeeStandards'
        ));
    }
    public function store(Request $request)
    {
        $request->validate([
            'employee_id' => 'required|exists:users,id',
            'month' => 'required|date_format:Y-m',
            'standards' => 'required|array',
            'standards.*' => 'nullable|numeric|min:0|max:100',
        ]);

        $employeeId = $request->employee_id;
        $month = $request->month;

        // Check for existing evaluation
        $existing = EmployeeEvaluation::where('employee_id', $employeeId)
            ->where('month', $month)
            ->first();

        if ($existing) {
            return back()->with('error', 'تم تقييم هذا الموظف بالفعل لهذا الشهر.');
        }

        // Create the evaluation with a default overall_rating of 0
        $evaluation = EmployeeEvaluation::create([
            'employee_id' => $employeeId,
            'month' => $month,
            'overall_rating' => 0, // Initial rating set to 0
            'department_id' =>auth()->user()->department_id,
            'assigned_by' => auth()->user()->id,
            'status' => 0,
        ]);

        $total = 0;
        $count = 0;

        foreach ($request->standards as $standardId => $score) {
            if ($score === null) continue;

            EmployeeEvaluationDetail::create([
                'employee_evaluation_id' => $evaluation->id,
                'standard_id' => $standardId,
                'score' => $score,
            ]);

            $total += $score;
            $count++;
        }

        // Recalculate and update overall rating if we have valid scores
        if ($count > 0) {
            $evaluation->update([
                'overall_rating' => round($total / $count, 2),
            ]);
        }

        return redirect()
            ->route('department_manager.evaluation.index', ['month' => $month])
            ->with('success', 'تم حفظ التقييم بنجاح.');
    }
    public function edit($evaluationId)
    {
        // Fetch the evaluation based on evaluation ID
        $evaluation = EmployeeEvaluation::with('employeeEvaluationDetails')
            ->where('id', $evaluationId)
            ->where('status', 0)  // Only evaluations with status 0 (in progress)
            ->whereNotNull('overall_rating')  // Ensure it has an overall rating
            ->first();
        
        // Check if the evaluation exists
        if (!$evaluation) {
            return redirect()->route('department_manager.evaluation.index', ['month' => now()->format('Y-m')])
                ->with('error', 'Evaluation not found or cannot be edited.');
        }
    
        // Fetch the employee details from the evaluation
        $employee = $evaluation->employee;
    
        // Fetch global and employee-specific standards
        $globalStandards = Standard::where('type', 'global')->where('status',1)->get();
        $employeeStandards = Standard::where('type', 'employee')
            ->where('employee_id', $employee->id)
            ->where('status',1)
            ->get();
    
        // Fetch the month from the evaluation (it's part of the `EmployeeEvaluation` record)
        $month = $evaluation->month;
        
        // Pass all required data to the view
        return view('department.evaluation.edit', compact('evaluation', 'employee', 'month', 'globalStandards', 'employeeStandards'));
    }
    
    public function update(Request $request, $evaluationId)
    {
        // Validate the input
        $validated = $request->validate([
            'standards.*' => 'required|numeric|min:0|max:100',
        ]);

        // Fetch the evaluation
        $evaluation = EmployeeEvaluation::findOrFail($evaluationId);

        // Submitted standard IDs and their scores
        $submittedScores = $validated['standards'];
        $submittedStandardIds = array_keys($submittedScores);

        // Calculate and update overall rating
        $evaluation->overall_rating = count($submittedScores) > 0
            ? array_sum($submittedScores) / count($submittedScores)
            : null;
        $evaluation->save();

        // Get existing standard IDs from DB
        $existingStandardIds = $evaluation->employeeEvaluationDetails()
            ->pluck('standard_id')
            ->toArray();

        // Delete old standards that are no longer submitted
        $toDelete = array_diff($existingStandardIds, $submittedStandardIds);
        if (!empty($toDelete)) {
            $evaluation->employeeEvaluationDetails()
                ->whereIn('standard_id', $toDelete)
                ->delete();
        }

        // Update or create submitted scores
        foreach ($submittedScores as $standardId => $score) {
            $evaluation->employeeEvaluationDetails()->updateOrCreate(
                ['standard_id' => $standardId],
                ['score' => $score]
            );
        }

        return redirect()->route('department_manager.evaluation.index', ['month' => $request->month])
            ->with('success', 'تم تعديل التقييم');
    }

public function changeStatus(Request $request)
    {
        // Get the department ID from the request
        $departmentId = $request->input('department_id');

        // Update all evaluations with status 0 to 1 for the given department
        User::where('department_id', $departmentId) // Filter by department
            ->where('role', 'employee') // Ensure we are targeting employees
            ->whereHas('employeeEvaluations', function ($query) { // Check if there is an evaluation with status = 0
                $query->where('status', 0);
            })
            ->each(function ($employee) {
                // Loop through each employee's evaluation and update the status to 1
                $employee->employeeEvaluations->each(function ($evaluation) {
                    $evaluation->update(['status' => 1]);
                });
            });

        // Redirect with a success message
        return redirect()->back()->with('success', 'تم تأكيد التقييمات لجميع الموظفين في القسم');
    }
  

    public function showEvaluation()
    {
        $evaluations = EmployeeEvaluation::where('status', 2)
            ->where('employee_id', auth()->id())
            ->orderBy('month', 'desc')
            ->get();


        return view('department.evaluation.view', compact('evaluations'));
    }

    public function details($month)
    {
        $evaluation = EmployeeEvaluation::with(['employeeEvaluationDetails.standard', 'employee'])
            ->where('month', $month)
            ->where('employee_id', auth()->user()->id)
            ->first();
    
        if (!$evaluation) {
            return redirect()->back()->with('error', 'لم يتم العثور على التقييم.');
        }
    
        return view('department.evaluation.details', [
            'evaluation' => $evaluation,
        ]);
    }


    public function deleteEvaluations(Request $request)
    {
        $deleted = \App\Models\EmployeeEvaluation::where('month', $request->month)
            ->where('department_id', $request->department_id)
            ->delete();
    
        return response()->json(['deleted' => $deleted]);
    }


}
