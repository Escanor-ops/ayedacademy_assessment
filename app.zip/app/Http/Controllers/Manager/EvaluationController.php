<?php

namespace App\Http\Controllers\Manager;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Standard;
use App\Models\Department;
use App\Models\EmployeeEvaluation;
use App\Models\EmployeeEvaluationDetail;
use Carbon\Carbon;

class EvaluationController extends Controller
{
    public function index(Request $request)
{

    $manager = auth()->user();

    // Get the current month
    $currentMonth = Carbon::now()->format('Y-m');

    $selectedMonth = $request->get('month', $currentMonth);

    // Get last 5 months that have evaluations for employees in the same department
    $months = EmployeeEvaluation::whereHas('employee', function ($query) use ($manager) {
        $query->where('department_id', $manager->department_id)
            ->where('role', 'department_managerr');
    })
    ->select('month')
    ->distinct()
    ->orderByDesc('month')
    ->limit(12)
    ->pluck('month');

    // Ensure current month is always in the list
    if (!$months->contains($currentMonth)) {
        $months->prepend($currentMonth);
    }

    // If selected month is not available, fallback to the latest available
    if (!$months->contains($selectedMonth)) {
        $selectedMonth = $months->first();
    }

    // Check if there is any evaluation with status 0 for the selected month in the current department
    $evaluationInProgress = EmployeeEvaluation::where('month', $selectedMonth)
        ->where('status', 0)
        ->whereHas('employee', function ($query) use ($manager) {
            $query->where('department_id', $manager->department_id);
        })
        ->exists(); // True if any evaluation with status 0 exists in the department for the selected month

    // Main logic: show employees based on selected month
    if ($selectedMonth === $currentMonth) {
        // Show ALL current employees in the department
        $employees = User::where('role', 'department_manager')

            ->where('status', 1)
            ->with(['employeeEvaluations' => function ($query) use ($selectedMonth) {
                $query->where('month', $selectedMonth);
            }])
            ->paginate(10)
            ->appends(['month' => $selectedMonth]);
    } else {
        // Show only employees who had evaluations in that past month
        $employees = User::where([
                ['role', '=', 'department_manager'],
                ['department_id', '=', $manager->department_id],
                ['status', '=', 1]
            ])
            ->whereHas('employeeEvaluations', function ($query) use ($selectedMonth) {
                $query->where('month', $selectedMonth);
            })
            ->with(['employeeEvaluations' => function ($query) use ($selectedMonth) {
                $query->where('month', $selectedMonth);
            }])
            ->paginate(10)
            ->appends(['month' => $selectedMonth]);
    }

    // Attach evaluation to each employee
    foreach ($employees as $employee) {
        $employee->evaluation = $employee->employeeEvaluations->first();
    }

    // Pass the evaluationInProgress flag to the view
    return view('manager.evaluation.index', compact('employees', 'months', 'selectedMonth', 'evaluationInProgress'));
}

public function create(Request $request)
    {
        $employee = User::findOrFail($request->employee);
        $month = $request->month;
    
        // Global standards (for all employees)
        $globalStandards = Standard::where('type', 'global')->get();
    
        // Employee-specific standards
        $employeeStandards = Standard::where('type', 'employee')
            ->where('employee_id', $employee->id)
            ->get();
    
        return view('manager.evaluation.create', compact(
            'employee', 'month', 'globalStandards', 'employeeStandards'
        ));
    }
    public function store(Request $request)
    {
        $request->validate([
            'employee_id' => 'required|exists:users,id',
            'month' => 'required|date_format:Y-m',
            'standards' => 'required|array',
            'standards.*' => 'nullable|numeric|min:0|max:100',
        ]);

        $employeeId = $request->employee_id;
        $user = User::findOrFail($employeeId);

        $month = $request->month;

        // Check for existing evaluation
        $existing = EmployeeEvaluation::where('employee_id', $employeeId)
            ->where('month', $month)
            ->first();

        if ($existing) {
            return back()->with('error', 'تم تقييم هذا الموظف بالفعل لهذا الشهر.');
        }

        // Create the evaluation with a default overall_rating of 0
        $evaluation = EmployeeEvaluation::create([
            'employee_id' => $employeeId,
            'month' => $month,
            'overall_rating' => 0, // Initial rating set to 0
            'department_id' =>$user->department_id,
            'assigned_by' => auth()->user()->id,
            'status' => 1,
        ]);

        $total = 0;
        $count = 0;

        foreach ($request->standards as $standardId => $score) {
            if ($score === null) continue;

            EmployeeEvaluationDetail::create([
                'employee_evaluation_id' => $evaluation->id,
                'standard_id' => $standardId,
                'score' => $score,
            ]);

            $total += $score;
            $count++;
        }

        // Recalculate and update overall rating if we have valid scores
        if ($count > 0) {
            $evaluation->update([
                'overall_rating' => round($total / $count, 2),
            ]);
        }

        return redirect()
            ->route('manager.evaluation.index', ['month' => $month])
            ->with('success', 'تم حفظ التقييم بنجاح.');
    }
    public function edit($evaluationId)
    {
        // Fetch the evaluation based on evaluation ID
        $evaluation = EmployeeEvaluation::with('employeeEvaluationDetails')
            ->where('id', $evaluationId)
            ->where('status', 1)  // Changed from 0 to 1 to allow editing evaluations with status 1
            ->whereNotNull('overall_rating')  // Ensure it has an overall rating
            ->first();
        
        // Check if the evaluation exists
        if (!$evaluation) {
            return redirect()->route('manager.evaluation.index', ['month' => now()->format('Y-m')])
                ->with('error', 'التقييم غير موجود أو لا يمكن تعديله.');
        }
    
        // Fetch the employee details from the evaluation
        $employee = $evaluation->employee;
    
        // Fetch global and employee-specific standards
        $globalStandards = Standard::where('type', 'global')->get();
        $employeeStandards = Standard::where('type', 'employee')
            ->where('employee_id', $employee->id)
            ->where('status', 1)
            ->get();
    
        // Fetch the month from the evaluation
        $month = $evaluation->month;
        
        // Pass all required data to the view
        return view('manager.evaluation.edit', compact('evaluation', 'employee', 'month', 'globalStandards', 'employeeStandards'));
    }
    
    public function update(Request $request, $evaluationId)
    {
        // Validate the input
        $validated = $request->validate([
            'standards.*' => 'required|numeric|min:0|max:100', // Ensure scores are numbers between 0 and 100
        ]);
    
        // Fetch the evaluation to update
        $evaluation = EmployeeEvaluation::findOrFail($evaluationId);
        
        // Check if evaluation can be updated (status must be 1)
        if ($evaluation->status !== 1) {
            return redirect()->back()->with('error', 'لا يمكن تعديل هذا التقييم في حالته الحالية.');
        }
    
        // Submitted scores and standard IDs
        $submittedScores = $validated['standards'];
        $submittedStandardIds = array_keys($submittedScores);
    
        // Update the overall rating
        $evaluation->overall_rating = count($submittedScores) > 0
            ? array_sum($submittedScores) / count($submittedScores)
            : null;
        $evaluation->save();
    
        // Get existing standard IDs from DB
        $existingStandardIds = $evaluation->employeeEvaluationDetails()
            ->pluck('standard_id')
            ->toArray();
    
        // Delete evaluation details that are not submitted anymore
        $toDelete = array_diff($existingStandardIds, $submittedStandardIds);
        if (!empty($toDelete)) {
            $evaluation->employeeEvaluationDetails()
                ->whereIn('standard_id', $toDelete)
                ->delete();
        }
    
        // Update or create submitted evaluation details
        foreach ($submittedScores as $standardId => $score) {
            $evaluation->employeeEvaluationDetails()->updateOrCreate(
                ['standard_id' => $standardId],
                ['score' => $score]
            );
        }
    
        return redirect()->route('manager.evaluation.index', ['month' => $request->month])
            ->with('success', 'تم تعديل التقييم بنجاح');
    }
    
    public function changeStatus(Request $request)
    {
        // Get the department ID from the request


        // Update all evaluations with status 0 to 1 for the given department
        User::where('role', 'department_manager') // Filter by department
            ->where('status', 1) // Ensure we are targeting employees
            ->whereHas('employeeEvaluations', function ($query) { 
                $query->where('status', 0);
            })
            ->each(function ($employee) {
                // Loop through each employee's evaluation and update the status to 1
                $employee->employeeEvaluations->each(function ($evaluation) {
                    $evaluation->update(['status' => 2]);
                });
            });

        // Redirect with a success message
        return redirect()->back()->with('success', 'تم تأكيد التقييمات لجميع الموظفين في القسم');
    }

    public function view($departmentId, $month)
    {
        // Fetch the department
        $department = Department::findOrFail($departmentId);

        // Fetch the evaluations for the department and selected month
        $evaluations = EmployeeEvaluation::whereHas('employee', function ($query) use ($department) {
            $query->where('department_id', $department->id);
        })
        ->where('month', $month)
        ->get();

        // Pass the evaluations and department to the view
        return view('manager.evaluation.view', compact('evaluations', 'department', 'month'));
    }
    public function empEvaluation($emp, $month)
    {
        $evaluation = EmployeeEvaluation::with(['employeeEvaluationDetails.standard', 'employee'])
            ->where('month', $month)
            ->where('employee_id', $emp)
            ->first();
    
        if (!$evaluation) {
            return redirect()->back()->with('error', 'لم يتم العثور على التقييم.');
        }
    
        return view('manager.evaluation.month', [
            'evaluation' => $evaluation,
            'type' => 'emp'
        ]);
    }

}
